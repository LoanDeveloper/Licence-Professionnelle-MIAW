<!-- W3.CSS Container -->
<div class="w3-light-grey w3-container w3-padding-32" style="margin-top:75px;padding-right:58px">
  <p class="w3-right">Copyright NOM Prénom</p>
</div>

<?php wp_footer(); ?>
</body>
</html>



